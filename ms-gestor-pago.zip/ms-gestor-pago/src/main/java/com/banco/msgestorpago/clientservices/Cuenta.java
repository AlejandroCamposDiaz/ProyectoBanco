package com.banco.msgestorpago.clientservices;

public class Cuenta {

	private String nrocuenta;
	private Double monto;
	
	public String getNrocuenta() {
		return nrocuenta;
	}
	public void setNrocuenta(String nrocuenta) {
		this.nrocuenta = nrocuenta;
	}
	public Double getMonto() {
		return monto;
	}
	public void setMonto(Double monto) {
		this.monto = monto;
	}
	
}
