package com.banco.msrecarga.negocio;

public interface RecargaNegocioInterface {
	
	public Transaccion procesarRecarga(Recarga recarga) throws Exception;

}
